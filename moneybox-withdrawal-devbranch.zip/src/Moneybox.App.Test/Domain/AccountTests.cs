using AutoFixture;
using Moneybox.App.DataAccess;
using Moneybox.App.Domain;
using Moneybox.App.Domain.Exceptions;
using Moneybox.App.Domain.Services;
using Moneybox.App.Features;
using NSubstitute;
using NUnit.Framework;

namespace Moneybox.App.Test.Domain
{
	public class AccountTests
	{
		private static Fixture _fixture;
		[SetUp]
		public void Setup()
		{
			_fixture = new Fixture();
		}

		[Test]
		public void TestWithdrawal()
		{
			var accountDetails = SetupMockedAccount();
			accountDetails.Balance = 1000;
			accountDetails.Withdrawn = 2000;
			accountDetails.Withdraw(500);
			Assert.AreEqual(500,accountDetails.Balance);
			Assert.AreEqual(2500, accountDetails.Withdrawn);
		}

		[Test]
		public void TestPayIn()
		{
			var accountDetails = SetupMockedAccount();
			accountDetails.Balance = 1000;
			accountDetails.PaidIn = 2000;
			accountDetails.PayIn(500);
			Assert.AreEqual(1500, accountDetails.Balance);
			Assert.AreEqual(2500, accountDetails.PaidIn);
		}

		[Test]
		public void TestApproachingPayInLimit()
		{
			var accountDetails = SetupMockedAccount();
			accountDetails.PaidIn = 3900;
			Assert.AreEqual(true, accountDetails.ApproachingPaidInLimit(50));
		}

		[Test]
		public void TestFundsLow()
		{
			var accountDetails = SetupMockedAccount();
			accountDetails.Balance = 499;
			Assert.AreEqual(true, accountDetails.FundsLow());
		}
		[Test]
		public void TestPayInLimitReached()
		{
			var accountDetails = SetupMockedAccount();
			accountDetails.PaidIn = 3999;
			Assert.Throws<PayInLimitReachedException>(delegate
			{
				accountDetails.ValidatePaidInLimit(2);
			});
		}

		[Test]
		public void TestValidateMinimumBalance()
		{
			var accountDetails = SetupMockedAccount();
			accountDetails.Balance = 1;
			Assert.Throws<InsufficientFundsException>(delegate
			{
				accountDetails.ValidateMinimumBalance(2);
			});
		}


		private static Account SetupMockedAccount()
		{
			var account = _fixture.Create<Account>();
			account.User = _fixture.Create<User>();
			return account;
		}

	}
}