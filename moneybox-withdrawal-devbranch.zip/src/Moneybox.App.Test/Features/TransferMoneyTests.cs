using AutoFixture;
using Moneybox.App.DataAccess;
using Moneybox.App.Domain;
using Moneybox.App.Domain.Exceptions;
using Moneybox.App.Domain.Services;
using Moneybox.App.Features;
using NSubstitute;
using NUnit.Framework;

namespace Moneybox.App.Test.Features
{
	public class TransferMoneyTests
	{
		private IAccountRepository _accountRepo;
		private INotificationService _notificationService;
		private static Fixture _fixture;
		[SetUp]
		public void Setup()
		{
			_accountRepo = Substitute.For<IAccountRepository>();
			_notificationService = Substitute.For<INotificationService>();
			_fixture = new Fixture();
		}

		[Test]
		public void TestSuccessfullyTransferred()
		{
			var fromAccountDetails = SetupMockedAccount();
			fromAccountDetails.Balance = 10000;
			var toAccountDetails = SetupMockedAccount();
			toAccountDetails.PaidIn = 0;
			_accountRepo.GetAccountById(fromAccountDetails.Id).Returns(fromAccountDetails);
			_accountRepo.GetAccountById(toAccountDetails.Id).Returns(toAccountDetails);
			var transferMoney = new TransferMoney(_accountRepo, _notificationService);
			transferMoney.Execute(fromAccountDetails.Id, toAccountDetails.Id, 3999);
		}

		[Test]
		public void TestInsufficientFunds()
		{
			var fromAccountDetails = SetupMockedAccount();
			fromAccountDetails.Balance = 0;
			var toAccountDetails = SetupMockedAccount();
			toAccountDetails.PaidIn = 0;
			_accountRepo.GetAccountById(fromAccountDetails.Id).Returns(fromAccountDetails);
			_accountRepo.GetAccountById(toAccountDetails.Id).Returns(toAccountDetails);
			var transferMoney = new TransferMoney(_accountRepo, _notificationService);
			Assert.Throws<InsufficientFundsException>(delegate
			{
				transferMoney.Execute(fromAccountDetails.Id, toAccountDetails.Id, 1);
			});
		}

		[Test]
		public void TestNotifyFundsLow()
		{
			var fromAccountDetails = SetupMockedAccount();
			fromAccountDetails.Balance = 499;
			var toAccountDetails = SetupMockedAccount();
			toAccountDetails.PaidIn = 0;
			_accountRepo.GetAccountById(fromAccountDetails.Id).Returns(fromAccountDetails);
			_accountRepo.GetAccountById(toAccountDetails.Id).Returns(toAccountDetails);
			var transferMoney = new TransferMoney(_accountRepo, _notificationService);
			transferMoney.Execute(fromAccountDetails.Id, toAccountDetails.Id, 100);
			_notificationService.Received().NotifyFundsLow(fromAccountDetails.User.Email);
		}

		[Test]
		public void TestPayInLimitReached()
		{
			var fromAccountDetails = SetupMockedAccount();
			fromAccountDetails.Balance = 5000;
			var toAccountDetails = SetupMockedAccount();
			toAccountDetails.PaidIn = 4001;
			_accountRepo.GetAccountById(fromAccountDetails.Id).Returns(fromAccountDetails);
			_accountRepo.GetAccountById(toAccountDetails.Id).Returns(toAccountDetails);
			var transferMoney = new TransferMoney(_accountRepo, _notificationService);
			Assert.Throws<PayInLimitReachedException>(delegate
			{
				transferMoney.Execute(fromAccountDetails.Id, toAccountDetails.Id, 1);
			});
		}

		[Test]
		public void TestApproachingPayInLimit()
		{
			var fromAccountDetails = SetupMockedAccount();
			fromAccountDetails.Balance = 5000;
			var toAccountDetails = SetupMockedAccount();
			toAccountDetails.PaidIn = 3500;
			_accountRepo.GetAccountById(fromAccountDetails.Id).Returns(fromAccountDetails);
			_accountRepo.GetAccountById(toAccountDetails.Id).Returns(toAccountDetails);
			var transferMoney = new TransferMoney(_accountRepo, _notificationService);
			transferMoney.Execute(fromAccountDetails.Id, toAccountDetails.Id, 100);
			_notificationService.Received().NotifyApproachingPayInLimit(toAccountDetails.User.Email);
		}


		private static Account SetupMockedAccount()
		{
			var account = _fixture.Create<Account>();
			account.User = _fixture.Create<User>();
			return account;
		}

	}
}