using AutoFixture;
using Moneybox.App.DataAccess;
using Moneybox.App.Domain;
using Moneybox.App.Domain.Exceptions;
using Moneybox.App.Domain.Services;
using Moneybox.App.Features;
using NSubstitute;
using NUnit.Framework;

namespace Moneybox.App.Test.Features
{
	public class WithdrawMoneyTests
	{
		private IAccountRepository _accountRepo;
		private INotificationService _notificationService;
		private static Fixture _fixture;
		[SetUp]
		public void Setup()
		{
			_accountRepo = Substitute.For<IAccountRepository>();
			_notificationService = Substitute.For<INotificationService>();
			_fixture = new Fixture();
		}

		[Test]
		public void TestSuccessfullyWithdrawn()
		{
			var fromAccountDetails = SetupMockedAccount();
			fromAccountDetails.Balance = 10000;
			_accountRepo.GetAccountById(fromAccountDetails.Id).Returns(fromAccountDetails);
			var withdrawMoney = new WithdrawMoney(_accountRepo, _notificationService);
			withdrawMoney.Execute(fromAccountDetails.Id, 3999);
		}

		[Test]
		public void TestInsufficientFunds()
		{
			var fromAccountDetails = SetupMockedAccount();
			fromAccountDetails.Balance = 0;
			_accountRepo.GetAccountById(fromAccountDetails.Id).Returns(fromAccountDetails);
			var withdrawMoney = new WithdrawMoney(_accountRepo, _notificationService);
			Assert.Throws<InsufficientFundsException>(delegate
			{
				withdrawMoney.Execute(fromAccountDetails.Id, 1);
			});
		}

		[Test]
		public void TestNotifyFundsLow()
		{
			var fromAccountDetails = SetupMockedAccount();
			fromAccountDetails.Balance = 499;
			_accountRepo.GetAccountById(fromAccountDetails.Id).Returns(fromAccountDetails);
			var withdrawMoney = new WithdrawMoney(_accountRepo, _notificationService);
			withdrawMoney.Execute(fromAccountDetails.Id, 100);
			_notificationService.Received().NotifyFundsLow(fromAccountDetails.User.Email);
		}

		private static Account SetupMockedAccount()
		{
			var account = _fixture.Create<Account>();
			account.User = _fixture.Create<User>();
			return account;
		}

	}
}