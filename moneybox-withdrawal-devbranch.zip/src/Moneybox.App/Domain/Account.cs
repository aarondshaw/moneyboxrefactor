﻿using System;
using Moneybox.App.Domain.Exceptions;

namespace Moneybox.App.Domain
{
    public class Account
    {
		// TODO these could be set as config vars, in a key vault/app config etc - this would likely be implemented in a new "thresholds" class or similar

	    private const decimal LowFundsThreshold = 500m;

	    private const decimal PayInLimit = 4000m;

	    private const decimal ApproachingPayInLimitThreshold = 500m;

        public Guid Id { get; set; }

        public User User { get; set; }

        public decimal Balance { get; set; }

        public decimal Withdrawn { get; set; }

        public decimal PaidIn { get; set; }

		public void ValidateMinimumBalance(decimal amount)
        {
	        if (Balance - amount < 0m)
	        {
		        throw new InsufficientFundsException("Insufficient funds to make transfer/withdrawal");
	        }
        }

		public void ValidatePaidInLimit(decimal amount)
		{
			if (PaidIn + amount > PayInLimit)
			{
				throw new PayInLimitReachedException("Account pay-in limit reached");
			}
		}

		public bool FundsLow()
		{
			return Balance < LowFundsThreshold;
		}

		public bool ApproachingPaidInLimit(decimal amount)
		{
			return PayInLimit - PaidIn - amount < ApproachingPayInLimitThreshold;
		}

		public void Withdraw(decimal amount)
		{
			Balance -= amount;
			Withdrawn += amount;
		}

		public void PayIn(decimal amount)
		{
			Balance += amount;
			PaidIn += amount;
		}
    }
}
