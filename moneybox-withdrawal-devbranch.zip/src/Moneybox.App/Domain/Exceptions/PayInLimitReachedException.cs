﻿using System;

namespace Moneybox.App.Domain.Exceptions
{

	public class PayInLimitReachedException : Exception
	{
		public PayInLimitReachedException(string message)
			: base(message)
		{
		}
	}

}
