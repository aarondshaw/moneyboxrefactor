﻿using Moneybox.App.DataAccess;
using Moneybox.App.Domain.Services;
using System;
using Moneybox.App.Domain.Exceptions;

namespace Moneybox.App.Features
{
    public class TransferMoney
    {
        private readonly IAccountRepository _accountRepository;
        private readonly INotificationService _notificationService;

        public TransferMoney(IAccountRepository accountRepository, INotificationService notificationService)
        {
            this._accountRepository = accountRepository;
            this._notificationService = notificationService;
        }

        public void Execute(Guid fromAccountId, Guid toAccountId, decimal amount)
        {
            var from = _accountRepository.GetAccountById(fromAccountId);
            var to = _accountRepository.GetAccountById(toAccountId);

            from.ValidateMinimumBalance(amount);
            if (from.FundsLow())
            {
	            _notificationService.NotifyFundsLow(from.User.Email);
            }

            to.ValidatePaidInLimit(amount);
            if (to.ApproachingPaidInLimit(amount))
            {
	            _notificationService.NotifyApproachingPayInLimit(to.User.Email);
            }

            from.Withdraw(amount);
            to.PayIn(amount);

            _accountRepository.Update(from);
            _accountRepository.Update(to);
        }
    }
}
